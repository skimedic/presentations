# EfCore
Samples and slides for Entity Framework Core presentations
