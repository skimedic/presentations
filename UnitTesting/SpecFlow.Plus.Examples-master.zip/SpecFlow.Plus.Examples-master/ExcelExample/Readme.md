# Excel Example
This example demonstrates the three usecases of using SpecFlow+ Excel.
* Defining full Features in Excel (CalculatorAdd.feature)
* Defining all examples in Excel (CalculatorSubtract.feature)
* Defining only a part of the used examples in Excel (CalculatorMultiply.feature)

Of course it is also possible to use non Excel Features alongside Excel Features (CalculatorDivide.feature)

 
