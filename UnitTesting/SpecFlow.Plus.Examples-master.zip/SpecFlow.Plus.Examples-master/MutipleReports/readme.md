# Multiple Reports Example

This is a example how to generate multiple Reports with Specflow and Specflow+ Runner.
It also shows how to use the "existingFileHandlingStrategy" attribute to preserve former reports

## Impotant
Make sure to set *Copy to Output Directory* for the custom templates to "Copy always", so that the Runner is able to find them.