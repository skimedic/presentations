# AppVeyor Example

This examples shows how to configure AppVeyor to use the SpecFlow+Runner

The appveyor.yml file is located here: https://github.com/techtalk/SpecFlow.Plus.Examples/blob/master/appveyor.yml  
Build example can be found here: https://ci.appveyor.com/project/SpecFlow/specflow-plus-examples