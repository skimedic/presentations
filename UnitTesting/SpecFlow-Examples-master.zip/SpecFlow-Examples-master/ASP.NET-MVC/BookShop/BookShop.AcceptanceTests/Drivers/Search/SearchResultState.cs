﻿using System.Web.Mvc;

namespace BookShop.AcceptanceTests.Drivers.Search
{
    public class SearchResultState
    {
        public ActionResult ActionResult { get; set; }
    }
}
