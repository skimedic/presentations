﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BookShop.UnitTests
{
    /// <summary>
    ///This is a test class for HomeControllerTest and is intended
    ///to contain all HomeControllerTest Unit Tests
    ///</summary>
    [TestClass]
    public class HomeControllerTest
    {
        //TODO: Unit-tests for the home controller (with mock/stub data access)
    }
}
