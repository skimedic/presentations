SpecFlow BowlingKata Sample - Generate Tests fom MsBuild
========================================================

This example shows how to generate/update the test classes during the build process using MsBuild.

More information: https://github.com/techtalk/SpecFlow/wiki/Generate-Tests-from-MsBuild
